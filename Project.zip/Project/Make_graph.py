import numpy as np
import pandas as pd
import itertools
import logging
import sys
import argparse
import operator
import matplotlib.pyplot as plt
import math
import time
from sklearn import cluster, datasets
from sklearn.neighbors import kneighbors_graph
from sklearn.preprocessing import StandardScaler
from q_values import *
import simplejson
new_node = 0
fo = open('new_node.txt' , 'rt')
lines = fo.readlines()
for line in lines:
	new_node = int(line)
#print new_node
total_vertices = 115
total_clusters = 12
theta_parameter = [[0.1 for i in xrange(total_clusters)] for i in xrange(total_vertices)]
adj_matrix = [[0.1 for i in xrange(total_vertices)] for i in xrange(total_vertices)]
edges = list()
vertices = list()
clusters = list()
cost = list()
interesting_nodes = set()

def updateQ(i , j):
	global theta_parameter
	global q_value
	sum_ = 0
	for k in xrange(total_clusters):
		sum_ += theta_parameter[i][k] * theta_parameter[j][k]
	if sum_ == 0:
		sum_ = 0.001
	for k in xrange(total_clusters):
		q_value[i][j][k] = theta_parameter[i][k] * theta_parameter[j][k] / sum_

fo = open('vertices.txt' , 'rt')
lines = fo.readlines()
for line in lines:
	vertices.append(int(line))
#print vertices
fo.close()

fo = open('edge_file.txt' , 'rt')
lines = fo.readlines()

for line in lines:
	edge = line.split(" ")
	source = int(edge[0])
	dest = int(edge[1].split('\n')[0])
	adj_matrix[source][dest] = 1
	if source == new_node or dest == new_node:
		updateQ(source , dest)
		interesting_nodes.add(source)
		interesting_nodes.add(dest)


fo.close()

fo = open('clusters.txt' , 'rt')
lines = fo.readlines()
k =0 
for line in lines:
	arr = line.split(' ')
	arr[-1] = arr[-1].split('\n')[0]
	for i in xrange(0,len(arr)):
		arr[i] = int(arr[i])
		theta_parameter[arr[i]][k] = 1
	clusters.append(arr)
	k+=1
#print clusters
fo.close()  
fo = open("q_values.py" , 'wb')
fo.write("q_value = ")
simplejson.dump(q_value , fo)
fo.close()


