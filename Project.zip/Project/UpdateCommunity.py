import numpy as np
import pandas as pd
import itertools
import logging
import argparse
import operator
import matplotlib.pyplot as plt
import math
import time
import sys
from sklearn import cluster, datasets
from sklearn.neighbors import kneighbors_graph
from sklearn.preprocessing import StandardScaler
from Make_graph import *
from last_arr import *
from graph_changers import *
interesting_nodes = list(interesting_nodes)
checker_flag = int(sys.argv[1])
temp = last_arr

def update_theta(vertex_no , community_no ): # function for updating theta function(propensity function)
	global adj_matrix
	global last_arr
	global interesting_nodes
	global q_value
	global theta_parameter
	summ= last_arr[community_no]
	for j in interesting_nodes:
		summ+= (adj_matrix[vertex_no][j]*q_value[vertex_no][j][community_no])
	temp[community_no] = summ
	summ = math.sqrt(summ)
	if summ == 0:
		summ = 0.001
	for i in xrange(1,total_vertices):
		theta_parameter[vertex_no][community_no] += adj_matrix[vertex_no][i]*q_value[vertex_no][i][community_no]
	theta_parameter[vertex_no][community_no]/=summ

def update_q_value(source , dest , k ): # function for updating q values
	global theta_parameter
	global q_value
	summ =0.0
	for i in xrange(total_clusters):
		summ+= theta_parameter[source][i]*theta_parameter[dest][i]
	q_value[source][dest][k] = float(theta_parameter[source][k])*theta_parameter[dest][k]/summ


iterations = 20
while iterations :
	iterations-=1
	for i in xrange(total_clusters):
		for j in interesting_nodes:
			update_theta(j , i )
		for j in interesting_nodes:
			update_q_value(new_node , j , i)
			update_q_value(j , new_node , i)
clu = [list() for i in xrange(total_clusters)]
#vertices.append(new_node)
constants = list()
changing = list()
for k in vertices:
	maxi = -1
	max_val = 0
	for i in xrange(total_clusters):
		#print i , theta_parameter[k][i]
		if maxi < theta_parameter[k][i]:
			maxi = theta_parameter[k][i]
			max_val = i
	if k!= new_node:
		if k in clusters[max_val]:
			constants.append(k)
		else:
			changing.append(k) 
	else:
		k-=1
		k+=1
		#print "New Node's cluster No." , max_val
		#print theta_parameter[k]
	clu[max_val].append(k)

fo = open('clusters.txt' , 'w')
#print "constants" , constants
#print "changing" , changing
if checker_flag == 1:
	for i in changing :
		graph_changers[i] += 1
fo.truncate()
#print clu
for i in clu:
	#print i , len(i)
	for j in xrange(len(i)-1):
		fo.write(str(i[j]))
		fo.write(" ")
	if len(i)!=0:
		fo.write(str(i[len(i)-1]) + "\n")
	else:
		fo.write(0)

fo.close()
last_arr = temp
open('q_values.py', 'w').close()
open('last_arr.py' , 'w').close()
open('graph_changers.py' , 'w').close()
fo = open("q_values.py" , 'wb')
lo = open('last_arr.py' , 'wb')
ro = open('graph_changers.py' , 'wb')
fo.write("q_value = ")
simplejson.dump(q_value , fo)
fo.close()
lo.write("last_arr = ")
simplejson.dump(last_arr , lo)
lo.close()
ro.write('graph_changers = ')
simplejson.dump(graph_changers , ro)


