import numpy as np
import pandas as pd
import itertools
import logging
import sys
import argparse
import operator
import matplotlib.pyplot as plt
import math
import time
from sklearn import cluster, datasets
from sklearn.neighbors import kneighbors_graph
from sklearn.preprocessing import StandardScaler
from expected_clusters import *
#from randomChooseNodes import total_clusters , total_of_each
total_clusters = 12
total_of_each = 3

startnodes = list()
fo = open('community.dat' , 'rt')
lines = fo.readlines()
dictio = dict()
counter = [0 for i in xrange(total_clusters)]
for line in lines:
	t = line.split(' ')
	t[0] = int(t[0])
	t[1] = int(t[1])
	dictio[t[0]] = t[1]
	#counter[t[1]]+=1
#print dictio

fo.close()


E = [0 for i in xrange(total_clusters)]
F = [0 for i in xrange(total_clusters)]
classes = list()

for r in expected_clusters.keys():
	i = expected_clusters[r]
	for j in xrange(total_of_each):
		startnodes.append(i[j])

print "Target Nodes are: " , startnodes
print '\n\n'
for i in startnodes:
	counter[dictio[i]] += 1

fo = open('clusters.txt' , 'rt')
temp = [[0 for i in xrange(total_clusters)] for i in xrange(total_clusters)]
lines = fo.readlines()
algoset = dict()
k=0
cluster_strength = [0 for i in xrange(total_clusters)]
for line in lines:
	splitter = line.split(' ')
	for j in splitter:
		if j[-1] == '\n':
			j = j[0:-1]
		algoset[int(j)] = k
	k+=1
#print algoset 

for i in startnodes:
	temp[algoset[i]][dictio[i]] += 1
	cluster_strength[algoset[i]]+=1
#print cluster_strength
for i in xrange(total_clusters):
	E[i] = -1
	F[i] = 1
	if cluster_strength[i] == 0:
		E[i] = 0.2
		F[i] = 0.8
	else:
		for j in xrange(total_clusters):
			E[i] = max(E[i] , float(temp[i][j])/cluster_strength[i])
			F[i] -= float(temp[i][j])*temp[i][j]/(cluster_strength[i]*cluster_strength[i])

#E = E[0:15]
print "E values are :    " , E
print '\n\n'
print "F values are :" , F
print '\n\n'
ans = 0
ans2 = 0
#print counter
for i in xrange(total_clusters):
	ans+= E[i]*counter[i]
for i in xrange(total_clusters):
	ans2+= F[i]*counter[i]
print "#################################################"
print "Average Cluster Purity" , ans/(total_clusters*(total_of_each))
print '\n'
print "Average Cluster Entropy" , ans2/(total_clusters*(total_of_each))
print "##################################################"









