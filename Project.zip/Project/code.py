import numpy as np
import pandas as pd
import itertools
import logging
import argparse
import operator
import matplotlib.pyplot as plt
import math
import time
from sklearn import cluster, datasets
from sklearn.neighbors import kneighbors_graph
from sklearn.preprocessing import StandardScaler
from initial_cluster import *





def update_theta(vertex_no , community_no ,  graph): # function for updating theta function(propensity function)
	global adj_matrix
	global q_value
	global theta_parameter
	summ= 0.0
	for i in xrange(1,1+len(graph.vertices)):
		for j in xrange(1,1+len(graph.vertices)):
			summ+= adj_matrix[i][j]*q_value[i][j][community_no]
	summ = math.sqrt(summ)
	for i in xrange(1,1+len(graph.vertices)):
		theta_parameter[vertex_no][community_no] += adj_matrix[vertex_no][i]*q_value[vertex_no][i][community_no]
	theta_parameter[vertex_no][community_no]/=summ


def initialize_q(vertices , clusters):
	global theta_parameter
	global q_value
	for j in xrange(1 , len(vertices)+1 ):
		for k in xrange(1, len(vertices)+1):
			summ = 0
			for i in clusters.keys():
				summ += theta_parameter[j][i]*theta_parameter[k][i]
			for i in clusters.keys():
				q_value[j][k][i] = theta_parameter[j][i]*theta_parameter[k][i]/summ

def update_q_value(source , dest , k , clusters): # function for updating q values
	global theta_parameter
	global q_value
	summ =0.0
	for i in clusters.keys():
		summ+= theta_parameter[source][i]*theta_parameter[dest][i]
	q_value[source][dest][k] = float(theta_parameter[source][k])*theta_parameter[dest][k]/summ


def update_network(graph , new_node , sampled_nodeset , all_clusters):
	global t
	iterations = 4 # total iterations kept fixed.
	initialize_q(graph.vertices , all_clusters)
	while iterations:
		print iterations
		for i in all_clusters.keys():
			for j in xrange(1,1+len(graph.vertices)):
				update_theta(j , i , graph)
			for j in graph.edges:
				update_q_value(j.source , j.dest , i ,all_clusters)
			

		iterations -= 1
	maxi = -1
	max_val = 0
	for i in all_clusters.keys():
		print i , theta_parameter[new_node][i]
		if maxi < theta_parameter[new_node][i]:
			maxi = theta_parameter[new_node][i]
			max_val = i
	print t , max_val

for t in xrange(30,35):
	print graph.vertices
	update_network(graph , t , vertices , clusters)

