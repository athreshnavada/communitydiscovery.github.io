python randomChooseNodes.py
for var in {1..50} 
do
	java -jar ire2.jar \
#if [ $var -gt 80 ] 
#	then
python UpdateCommunity.py 1 \
#else
	#python UpdateCommunity.py 0 \
#fi

done
python accuracy.py