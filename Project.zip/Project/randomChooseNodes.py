import numpy as np
import pandas as pd
import itertools
import logging
import argparse
import operator
import matplotlib.pyplot as plt
import math
import time
from sklearn import cluster, datasets
from sklearn.neighbors import kneighbors_graph
from sklearn.preprocessing import StandardScaler
import pickle
import simplejson
from random import shuffle
total_of_each = 4
total_vertices = 115
total_clusters = 12
last_arr = [0 for i in xrange(total_clusters)]
q_value = [[[0 for i in xrange(total_clusters)] for i in xrange(total_vertices)] for i in xrange(total_vertices)]
theta_parameter = [[0.1 for i in xrange(total_clusters)] for i in xrange(total_vertices)]
adj_matrix = [[0.1 for i in xrange(total_vertices)] for i in xrange(total_vertices)]
vertices = list()
clusters = dict()
#infile = open("q_values.py" , 'rt')
#q_value = pickle.load(infile)

class edge:
	def __init__(self , x , y):
		self.source =  x
		self.dest = y

class Graph:
	def __init__(self , vertices , edges , cost):
		self.vertices = vertices
		self.edges = edges
		self.cost = cost
graph = Graph(list(), list() , list())


input_file = open('network.dat' , 'rt')
lines = input_file.readlines()
for line in lines:
	info = line.split(' ')
	adj_matrix[int(info[0])][int(info[1])] = 1
kk = np.array(adj_matrix)

spectral = cluster.SpectralClustering(n_clusters=total_clusters,
                                      eigen_solver='arpack',affinity = 'precomputed')
spectral.fit(kk)
y_predict = spectral.labels_.astype(np.int)
keep =0
clustering = list()
for itera in y_predict:
	if keep == 0:
		keep+=1
		continue
	clustering.append((keep,itera))
	keep+=1


#print clustering
for i in clustering:
	if i[1] not in clusters.keys():
		clusters[i[1]] = list()
		clusters[i[1]].append(i[0])
	else:
		clusters[i[1]].append(i[0])
open('expected_clusters.py').close()
fo = open('expected_clusters.py' , 'wb')
fo.write('expected_clusters = ')
fo.write(str(clusters))
fo.close()
#print clusters
fo = open("vertices.txt" , 'wb')
lo = open("clusters.txt" , 'wb')
vset = set()
eset = set()
#print clusters
for i in clusters.keys():
	upper_limit = total_of_each-1
	#shuffle(clusters[i])
	for j in xrange(total_of_each):
		#print clusters[i][j] ,i 
		#print i ,j
		vertices.append(clusters[i][j])
		#print clusters[i][j] , i
		theta_parameter[clusters[i][j]][i] = 1
		lo.write(str(clusters[i][j]))
		if(j!=upper_limit):
			lo.write(" ")
		else:
			lo.write("\n")
		fo.write(str(clusters[i][j]) + "\n")
fo.close()
lo.close()
#print vertices

fo = open('edge_file.txt' , 'wb')
for i in vertices:
	for j in xrange(total_vertices):
		if adj_matrix[i][j] == 1:
			fo.write(str(i) + " " + str(j) + "\n")
			if j not in vertices:
				fo.write(str(j) +  " "  + str(i) + "\n")
fo.close()

# Initial Q value

for j in xrange(len(vertices) ):
	for k in xrange(len(vertices)):
		summ = 0
		for i in xrange(total_clusters):
			summ += theta_parameter[j][i]*theta_parameter[k][i]
		if summ == 0:
			summ = 0.001
		for i in xrange(total_clusters):
			q_value[j][k][i] = theta_parameter[j][i]*theta_parameter[k][i]/summ
			last_arr[i] += q_value[j][k][i]* adj_matrix[j][k]

for i in xrange(total_clusters):
	last_arr[i]+=0.01

graph_changers = [0 for i in xrange(total_vertices)]
open('q_values.py', 'w').close()
open('last_arr.py' , 'w').close()
open('graph_changers.py' , 'w').close()
ro = open('graph_changers.py' , 'wb')
fo = open("q_values.py" , 'wb')
lo = open('last_arr.py' , 'wb')
fo.write("q_value = ")
simplejson.dump(q_value , fo)
fo.close()
lo.write("last_arr = ")
simplejson.dump(last_arr , lo)
lo.close()
ro.write("graph_changers = ")
simplejson.dump(graph_changers , ro)
ro.close()
